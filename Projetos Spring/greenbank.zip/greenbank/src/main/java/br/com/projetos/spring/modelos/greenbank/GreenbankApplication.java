package br.com.projetos.spring.modelos.greenbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenbankApplication.class, args);
	}

}
