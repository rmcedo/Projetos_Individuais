package br.com.projetos.spring.modelos.greenbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
